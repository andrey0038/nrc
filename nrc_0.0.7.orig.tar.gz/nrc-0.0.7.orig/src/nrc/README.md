# nrc
RDP GUI for freerdp2-x11  
This is fork of https://github.com/dbachilo/nrc
